/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package institutmvm.exersie1;

import java.util.Scanner;

/**
 *
 * @author alumne_1r
 */
public class exercise3F {
    public static final String MSG_1 = "introduce un primer numero";
    public static final String MSG_2 = "introduce un segun numero";
    public static void main(String[] args) {
        int num1,num2 ;
        Scanner sc = new Scanner(System.in);
        System.out.println(MSG_1);
        num1 = sc.nextInt();
         System.out.println(MSG_2);
        num2 = sc.nextInt();
        if ((num1/num2 < 15 )) {
         System.out.println(" és menor que 15 :");
        } else {
        System.out.println(" No és menor que 15 :");
        }
}
}