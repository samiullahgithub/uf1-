/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package institutmvm.exersie1;

/**
 *
 * @author alumne_1r
 */
public class exercise3 {
    public static 
    
}
