/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package institutmvm.exersie1;

/**
 *
 * @author alumne_1r
 */
public class NewClass {
//nombre/
public static final String MSG_1= "Samiullah"; 
//cognom/
public static final String MSG_2= "ullah"; 
//institut/
public static final String MSG_3= "INS Manuel Vázquez Montalbán"; 
//data edicio/
public static final String MSG_4= "10-11-2022"; 
//ciclo/
public static final String MSG_5= "ASIX_1n";
///
//model/
public static final String MSG_6= "Programacion";

public static void main(String[] args) {
        System.out.println("Nom: " +MSG_1);
        System.out.println("Cognoms: " +MSG_2);
        System.out.println("Institut: " +MSG_3);
        System.out.println("Data d’edició: " +MSG_4);
        System.out.println("Nom del cicle formatiu: " +MSG_5);
        System.out.println("Nom del mòdul: " + MSG_6);
        
        
}
}
