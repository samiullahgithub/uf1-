/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package institutmvm.exersie1;

import java.util.Scanner;

/**
 *
 * @author alumne_1r
 */
public class exersise3D {

    public static final String MSG_1 = "introduce un numero";

    public static void main(String[] args) {
        int num1;
        Scanner sc = new Scanner(System.in);
        System.out.println(MSG_1);
        num1 = sc.nextInt();
        if (num1 < 3 && num1 > 27) {
            System.out.println("és interval [-3,27] :" + num1);
        } else {
            System.out.println("No és interval [-3,27] :" + num1);
        }
    }

}
