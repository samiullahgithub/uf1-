/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package institutmvm.exersie1;

/**
 *
 * @author alumne_1r
 */
public class Mavenproject1 {
public static final String MSG_1= "SAmiullah"; 
public static final String MSG_2= "ullah"; 
public static final String MSG_3= "ullah\n"; 

    public static void main(String[] args) {
        System.out.println(MSG_1);
        System.out.println(MSG_1 + " " + MSG_2);
        System.out.println(MSG_1 + " " +MSG_3);
        System.out.println("         * ");
        System.out.println("        * *");
        System.out.println("       * * *");
        System.out.println("      * * * *");
        System.out.println("     * * * * *");
        System.out.println("    * * * * * *");
        System.out.println("   * * * * * * * ");
        System.out.println("  * * * * * * * *");
        System.out.println(" * * * * * * * * *");
        System.out.println("* * * * * * * * * *");
    }
}
