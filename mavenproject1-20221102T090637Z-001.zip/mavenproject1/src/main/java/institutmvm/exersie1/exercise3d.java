/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package implementacio.java;

import java.util.Scanner;

public class exercise3 {

    public static final String MSG_1 = "introduce un numero";

    public static void main(String[] args) {
        int num1;
        Scanner sc = new Scanner(System.in);
        System.out.println(MSG_1);
        num1 = sc.nextInt();
        if (num1 < -0) {
            System.out.println("Nombre és negatiu " + num1);
        } else {
            if (num1 > 35){
                System.out.println("més gran que 35");
            } else {
                System.out.println("és menor que 35");
            }
            if   (num1 > 0 && num1 < 100) {
                System.out.println("menor que 100");
            } else {
                System.out.println("més gran que 100");
            }
          
        }
    }
}

